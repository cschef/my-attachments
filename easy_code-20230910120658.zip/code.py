import base64

def encode1(code):
    res = ''
    for i in code:
        x = ord(i) ^ 31
        x = x + 24
        res += chr(x)

    return res


def encode2(code):
    res = ''
    for i in code:
        x = ord(i) + 31
        x = x ^ 31
        res += chr(x)

    return res


def encode3(code):
    return base64.b32encode(code)


flag = ' '
print 'Please Input your flag:'
flag = raw_input()
final = 'V622VMEEVWVEC7FMPV7265VLPN7X25T5V2XKW5VLVZBKY5TZPN4UA7CBIKX2U6NKVODA===='
if encode3(encode2(encode1(flag))) == final:
    print 'yes'
else:
    print 'no'